#!/bin/bash
ln -sf fe/bower_components
ln -sf fe/node_modules
node server.js 
